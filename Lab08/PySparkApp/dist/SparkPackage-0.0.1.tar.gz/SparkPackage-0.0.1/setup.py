import setuptools

setuptools.setup(
    name='SparkPackage',
    version='0.0.1',
    packages=setuptools.find_packages()
)